# Online Quiz System

Backend-intensive quiz platform. **HTML/CSS/JS** frontend, **Node.js + Express** API, **MySQL** database.
The Express server also serves the frontend, so everything runs on one port.

## Quick start
```bash
# 1. MySQL 8 (or MariaDB 10.5+) - use your own, or:  docker compose up -d
# 2. Backend
cd backend
npm install
cp .env.example .env        # edit DB_USER / DB_PASSWORD / JWT_SECRET
npm run setup               # creates database + tables + demo data
npm start                   # http://localhost:3000
```
Open http://localhost:3000

| Role | Email | Password |
|---|---|---|
| Admin | admin@quiz.com | Admin@123 |
| Student | student@quiz.com | Student@123 |

New registrations are always students. Admin accounts are created only via the seed script/DB.

## How the requirements are met

**Server-controlled timed quizzes** - On start, `expires_at = DATE_ADD(NOW(), INTERVAL duration MINUTE)` is computed by the *database clock*. The browser countdown is only a display and is re-synced from the server on every autosave. Late answers are rejected (409); a final submit is accepted only within `SUBMIT_GRACE_SECONDS` of the deadline. A background job (every 30 s) auto-submits abandoned attempts, and attempts are also closed lazily when touched. Refreshing the page resumes with the real remaining time.

**Secure question and answer storage** - Correct answers live in `options.is_correct` and are never selected by any student endpoint. They are revealed only after the attempt is closed. Passwords use bcrypt, auth uses JWT, queries are parameterized, all UI text is inserted via `textContent` (no XSS), helmet + rate limiting on auth routes. Answers are checked to belong to the attempt's own quiz.

**Score calculation and persistence** - Scored in SQL by joining `attempt_answers → options (is_correct=1) → questions` and summing marks. Score, total, percentage, pass/fail, status and timestamps are stored on `attempts`, and results can't change after submission.

**Relational design (3NF)**
```
users 1─* quizzes(created_by)      quizzes 1─* questions 1─* options
users 1─* attempts *─1 quizzes     attempts 1─* attempt_answers *─1 questions / options
```
Constraints: PK/FK everywhere, `UNIQUE(user_id, quiz_id)` (one attempt per student per quiz), `UNIQUE(attempt_id, question_id)`, `UNIQUE(quiz_id, position)`, CHECKs (duration 1-300, pass 0-100, marks > 0), `ON DELETE RESTRICT` on attempts (results can't be lost by deleting a quiz/user), `ON DELETE CASCADE` for questions/options/answers, and a generated column + unique index so **MySQL itself guarantees exactly ≤1 correct option per question**.

**Joins used** - student quiz list (LEFT JOIN attempts), results review (questions JOIN options LEFT JOIN answers), leaderboard (attempts JOIN users, ranked), admin list (quizzes JOIN users LEFT JOIN attempts + GROUP BY/AVG), stats subqueries.

**Admin management** - Create/edit/delete quizzes with a question builder, publish/unpublish, dashboard stats, per-quiz leaderboard, reset a student's attempt. Question edits are blocked once attempts exist (409); quizzes with stored results can't be deleted (unpublish instead).

**Validation and errors** - express-validator on every route, transactions for multi-row writes, one error format: `{success:false, message, errors:[{field,message}]}`; MySQL errors (duplicate, FK, check) are mapped to proper 4xx codes.

## API
Student: `POST /api/auth/register|login`, `GET /api/auth/me`, `GET /api/quizzes`, `POST /api/quizzes/:id/start`, `GET /api/attempts/:id`, `PUT /api/attempts/:id/answers`, `POST /api/attempts/:id/submit`, `GET /api/attempts/:id/result`, `GET /api/attempts/mine`
Admin (role=admin): `GET /api/admin/stats`, `GET|POST /api/admin/quizzes`, `GET|PUT|DELETE /api/admin/quizzes/:id`, `PATCH /api/admin/quizzes/:id/publish`, `GET /api/admin/quizzes/:id/results`, `DELETE /api/admin/attempts/:id`

## Structure
```
backend/db/schema.sql, init.js, seed.js
backend/src/{config,controllers,middleware,routes,services,utils}, app.js, server.js
frontend/index.html, css/styles.css, js/{app,api,ui}.js, js/views/{auth,student,take,admin}.js
```
Manual schema install (e.g. MySQL Workbench): run `backend/db/schema.sql`.
