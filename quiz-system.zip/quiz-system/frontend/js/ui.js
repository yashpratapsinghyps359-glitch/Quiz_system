// Tiny DOM helper. All text is inserted with textContent/createTextNode => no XSS from quiz content.
export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k === 'class') node.className = v;
    else if (k.startsWith('on')) node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'checked' || k === 'value' || k === 'disabled' || k === 'selected') node[k] = v;
    else if (v === true) node.setAttribute(k, '');
    else if (v !== false && v != null) node.setAttribute(k, v);
  }
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    node.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return node;
}

export const mount = (node) => document.getElementById('app').replaceChildren(node);

export function toast(message, type = 'info') {
  const t = el('div', { class: `toast toast-${type}` }, message);
  document.getElementById('toasts').append(t);
  setTimeout(() => t.remove(), 3500);
}

export const fmtDate = (d) => (d ? new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '-');
export const fmtClock = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
export const fmtSecs = (s) => (s == null ? '-' : `${Math.floor(s / 60)}m ${s % 60}s`);

export function badge(text, kind = 'gray') { return el('span', { class: `badge badge-${kind}` }, text); }

export function field(label, input, error) {
  return el('label', { class: 'field' }, el('span', {}, label), input, error ? el('small', { class: 'err' }, error) : null);
}
