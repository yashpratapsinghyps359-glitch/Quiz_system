const TOKEN = 'quiz_token';
const USER = 'quiz_user';

export const session = {
  token: () => localStorage.getItem(TOKEN),
  user: () => { try { return JSON.parse(localStorage.getItem(USER)); } catch { return null; } },
  save(token, user) { localStorage.setItem(TOKEN, token); localStorage.setItem(USER, JSON.stringify(user)); },
  clear() { localStorage.removeItem(TOKEN); localStorage.removeItem(USER); },
};

export class ApiError extends Error {
  constructor(message, status, errors) { super(message); this.status = status; this.errors = errors || []; }
  get fields() { const f = {}; this.errors.forEach((e) => { if (!f[e.field]) f[e.field] = e.message; }); return f; }
}

export async function api(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      headers: { 'Content-Type': 'application/json', ...(session.token() && { Authorization: `Bearer ${session.token()}` }) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('Cannot reach the server', 0);
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && !path.startsWith('/auth/')) {
      session.clear();
      location.hash = '#/login';
    }
    throw new ApiError(data.message || 'Something went wrong', res.status, data.errors);
  }
  return data;
}
