import { el, mount, toast, fmtClock } from '../ui.js';
import { api } from '../api.js';

export async function takeView(attemptId) {
  const data = await api(`/attempts/${attemptId}`);
  if (data.finished) { location.hash = `#/result/${attemptId}`; return; }

  const { attempt, questions } = data;
  const answers = { ...data.answers };
  let current = 0;
  let deadline = performance.now() + attempt.remainingSeconds * 1000; // server-provided remaining time
  let submitting = false;

  const timerEl = el('div', { class: 'timer' });
  const saveEl = el('small', { class: 'muted' });
  const body = el('div');
  const nav = el('div', { class: 'qnav' });

  async function submit(auto = false) {
    if (submitting) return;
    if (!auto) {
      const left = questions.length - Object.keys(answers).length;
      if (!confirm(left ? `You have ${left} unanswered question(s). Submit anyway?` : 'Submit your quiz now?')) return;
    }
    submitting = true;
    try {
      await api(`/attempts/${attemptId}/submit`, { method: 'POST', body: {
        answers: Object.entries(answers).map(([q, o]) => ({ questionId: +q, optionId: +o })) } });
      if (auto) toast('Time is up - your quiz was submitted', 'info');
      location.hash = `#/result/${attemptId}`;
    } catch (e) { submitting = false; toast(e.message, 'error'); }
  }

  async function choose(qid, oid) {
    answers[qid] = oid;
    draw();
    saveEl.textContent = 'Saving...';
    try {
      const r = await api(`/attempts/${attemptId}/answers`, { method: 'PUT', body: { questionId: qid, optionId: oid } });
      deadline = performance.now() + r.remainingSeconds * 1000; // re-sync with server clock
      saveEl.textContent = 'Saved';
    } catch (e) {
      saveEl.textContent = '';
      if (e.status === 409) { submit(true); } else toast(e.message, 'error');
    }
  }

  function draw() {
    const q = questions[current];
    body.replaceChildren(
      el('div', { class: 'card' },
        el('div', { class: 'row-between' }, el('small', { class: 'muted' }, `Question ${current + 1} of ${questions.length}`), el('small', { class: 'muted' }, `${q.marks} mark${q.marks > 1 ? 's' : ''}`)),
        el('h3', {}, q.text),
        el('div', { class: 'choices' }, q.options.map((o) =>
          el('label', { class: `choice ${answers[q.id] === o.id ? 'choice-on' : ''}` },
            el('input', { type: 'radio', name: `q${q.id}`, checked: answers[q.id] === o.id, onchange: () => choose(q.id, o.id) }),
            el('span', {}, o.text)))),
        el('div', { class: 'row-between' },
          el('button', { class: 'btn btn-ghost', disabled: current === 0, onclick: () => { current--; draw(); } }, 'Previous'),
          saveEl,
          current < questions.length - 1
            ? el('button', { class: 'btn', onclick: () => { current++; draw(); } }, 'Next')
            : el('button', { class: 'btn btn-success', onclick: () => submit(false) }, 'Submit quiz'))));
    nav.replaceChildren(...questions.map((qq, i) =>
      el('button', { class: `qdot ${i === current ? 'qdot-cur' : ''} ${answers[qq.id] ? 'qdot-done' : ''}`, onclick: () => { current = i; draw(); } }, i + 1)));
  }

  const tick = () => {
    const s = Math.max(0, Math.ceil((deadline - performance.now()) / 1000));
    timerEl.textContent = fmtClock(s);
    timerEl.classList.toggle('timer-warn', s <= 60);
    if (s <= 0) { clearInterval(iv); submit(true); }
  };
  const iv = setInterval(tick, 250);

  mount(el('section', {},
    el('div', { class: 'card row-between sticky' }, el('h2', {}, attempt.title), timerEl),
    nav, body,
    el('p', { class: 'muted small' }, 'The timer is controlled by the server. Answers are saved as you go, and the quiz auto-submits when time ends.')));
  draw(); tick();
  return () => clearInterval(iv);
}
