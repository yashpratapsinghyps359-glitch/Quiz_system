import { el, mount, badge, toast, fmtDate, fmtSecs } from '../ui.js';
import { api } from '../api.js';

export async function dashboardView() {
  const { data } = await api('/quizzes');
  const start = async (id) => {
    try {
      const d = await api(`/quizzes/${id}/start`, { method: 'POST' });
      location.hash = `#/quiz/${d.attemptId}`;
    } catch (e) { toast(e.message, 'error'); }
  };

  const card = (q) => {
    let action, state = null;
    if (!q.attempt_id) action = el('button', { class: 'btn', onclick: () => start(q.id) }, 'Start quiz');
    else if (q.attempt_status === 'in_progress') {
      state = badge('In progress', 'blue');
      action = el('button', { class: 'btn', onclick: () => start(q.id) }, 'Resume');
    } else {
      state = badge(q.passed ? `Passed · ${Number(q.percentage)}%` : `Failed · ${Number(q.percentage)}%`, q.passed ? 'green' : 'red');
      action = el('a', { class: 'btn btn-ghost', href: `#/result/${q.attempt_id}` }, 'View result');
    }
    return el('div', { class: 'card quiz-card' },
      el('div', { class: 'row-between' }, el('h3', {}, q.title), state),
      el('p', { class: 'muted' }, q.description || 'No description'),
      el('div', { class: 'meta' },
        el('span', {}, `${q.question_count} questions`), el('span', {}, `${q.duration_minutes} min`),
        el('span', {}, `${q.total_marks} marks`), el('span', {}, `Pass ≥ ${q.pass_percentage}%`)),
      el('div', { class: 'actions' }, action));
  };

  mount(el('section', {},
    el('h2', {}, 'Available quizzes'),
    data.length ? el('div', { class: 'grid' }, data.map(card)) : el('p', { class: 'card center muted' }, 'No quizzes are published yet.')));
}

export async function resultView(id) {
  const { data: r } = await api(`/attempts/${id}/result`);
  const review = r.questions.map((q, i) =>
    el('div', { class: 'card review' },
      el('div', { class: 'row-between' },
        el('strong', {}, `Q${i + 1}. ${q.text}`),
        !q.answered ? badge('Not answered', 'gray') : q.correct ? badge(`+${q.marks}`, 'green') : badge('Wrong', 'red')),
      el('ul', { class: 'opts' }, q.options.map((o) =>
        el('li', { class: `opt ${o.isCorrect ? 'opt-correct' : ''} ${o.selected && !o.isCorrect ? 'opt-wrong' : ''}` },
          o.text,
          o.isCorrect ? el('small', {}, ' ✓ correct answer') : null,
          o.selected ? el('small', {}, ' · your answer') : null)))));

  mount(el('section', {},
    el('a', { href: '#/' }, '← Back to quizzes'),
    el('div', { class: 'card result-head' },
      el('div', { class: `score ${r.passed ? 'pass' : 'fail'}` }, `${r.percentage}%`),
      el('div', {},
        el('h2', {}, r.quiz),
        el('p', {}, `${r.score} / ${r.totalMarks} marks · `, badge(r.passed ? 'Passed' : 'Failed', r.passed ? 'green' : 'red'),
          r.status === 'expired' ? badge('Auto-submitted (time up)', 'amber') : null),
        el('p', { class: 'muted' }, `Pass mark ${r.passPercentage}% · submitted ${fmtDate(r.submittedAt)}`))),
    el('h3', {}, 'Answer review'), review));
}
