import { el, mount, badge, toast, fmtDate, fmtSecs, field } from '../ui.js';
import { api, ApiError } from '../api.js';

export async function adminDashboardView() {
  const [{ data: s }, { data: quizzes }] = await Promise.all([api('/admin/stats'), api('/admin/quizzes')]);
  const metric = (label, value) => el('div', { class: 'metric' }, el('strong', {}, value ?? 0), el('span', {}, label));

  const act = async (fn, msg) => { try { await fn(); toast(msg, 'success'); adminDashboardView(); } catch (e) { toast(e.message, 'error'); } };

  mount(el('section', {},
    el('div', { class: 'row-between' }, el('h2', {}, 'Admin dashboard'), el('a', { class: 'btn', href: '#/admin/new' }, '+ New quiz')),
    el('div', { class: 'metrics' },
      metric('Students', s.students), metric('Quizzes', s.quizzes), metric('Submissions', s.attempts),
      metric('Average score', s.avg_score == null ? '-' : `${s.avg_score}%`), metric('Pass rate', s.pass_rate == null ? '-' : `${s.pass_rate}%`)),
    el('div', { class: 'card table-wrap' }, el('table', {},
      el('thead', {}, el('tr', {}, ['Title', 'Questions', 'Time', 'Submissions', 'Avg', 'Status', ''].map((h) => el('th', {}, h)))),
      el('tbody', {}, quizzes.length ? quizzes.map((q) => el('tr', {},
        el('td', {}, q.title), el('td', {}, q.question_count), el('td', {}, `${q.duration_minutes} min`),
        el('td', {}, q.attempts), el('td', {}, q.avg_score == null ? '-' : `${q.avg_score}%`),
        el('td', {}, badge(q.is_published ? 'Published' : 'Draft', q.is_published ? 'green' : 'gray')),
        el('td', { class: 'actions-cell' },
          el('a', { class: 'btn btn-sm btn-ghost', href: `#/admin/results/${q.id}` }, 'Results'),
          el('a', { class: 'btn btn-sm btn-ghost', href: `#/admin/edit/${q.id}` }, 'Edit'),
          el('button', { class: 'btn btn-sm btn-ghost', onclick: () => act(() => api(`/admin/quizzes/${q.id}/publish`, { method: 'PATCH', body: { isPublished: !q.is_published } }), q.is_published ? 'Unpublished' : 'Published') }, q.is_published ? 'Unpublish' : 'Publish'),
          el('button', { class: 'btn btn-sm btn-danger', onclick: () => confirm(`Delete "${q.title}"?`) && act(() => api(`/admin/quizzes/${q.id}`, { method: 'DELETE' }), 'Quiz deleted') }, 'Delete'))))
        : el('tr', {}, el('td', { colspan: 7, class: 'center muted' }, 'No quizzes yet.')))))));
}

export async function quizResultsView(id) {
  const { quiz, data } = await api(`/admin/quizzes/${id}/results`);
  const reset = async (aid) => {
    if (!confirm('Reset this attempt so the student can retake the quiz?')) return;
    try { await api(`/admin/attempts/${aid}`, { method: 'DELETE' }); toast('Attempt reset', 'success'); quizResultsView(id); } catch (e) { toast(e.message, 'error'); }
  };
  mount(el('section', {},
    el('a', { href: '#/admin' }, '← Back'),
    el('h2', {}, `Results: ${quiz.title}`),
    el('div', { class: 'card table-wrap' }, el('table', {},
      el('thead', {}, el('tr', {}, ['#', 'Student', 'Score', '%', 'Result', 'Time taken', 'Submitted', ''].map((h) => el('th', {}, h)))),
      el('tbody', {}, data.length ? data.map((r, i) => el('tr', {},
        el('td', {}, i + 1), el('td', {}, `${r.name} `, el('small', { class: 'muted' }, r.email)),
        el('td', {}, `${r.score}/${r.total_marks}`), el('td', {}, `${r.percentage}%`),
        el('td', {}, badge(r.passed ? 'Passed' : 'Failed', r.passed ? 'green' : 'red'), r.status === 'expired' ? badge('Timed out', 'amber') : null),
        el('td', {}, fmtSecs(r.seconds_taken)), el('td', {}, fmtDate(r.submitted_at)),
        el('td', {}, el('a', { class: 'btn btn-sm btn-ghost', href: `#/result/${r.id}` }, 'Review'),
          el('button', { class: 'btn btn-sm btn-danger', onclick: () => reset(r.id) }, 'Reset'))))
        : el('tr', {}, el('td', { colspan: 8, class: 'center muted' }, 'No submissions yet.')))))));
}

const blankQuestion = () => ({ text: '', marks: 1, options: [{ text: '', isCorrect: true }, { text: '', isCorrect: false }] });

export async function quizEditorView(id) {
  let quiz = { title: '', description: '', durationMinutes: 10, passPercentage: 40, isPublished: false, questions: [blankQuestion()], locked: false };
  if (id) quiz = (await api(`/admin/quizzes/${id}`)).data;
  let fieldErrors = {};
  let topError = '';

  const read = (root) => {
    quiz.title = root.querySelector('[name=title]').value;
    quiz.description = root.querySelector('[name=description]').value;
    quiz.durationMinutes = +root.querySelector('[name=duration]').value;
    quiz.passPercentage = +root.querySelector('[name=pass]').value;
    quiz.isPublished = root.querySelector('[name=published]').checked;
  };

  async function save(root) {
    read(root);
    fieldErrors = {}; topError = '';
    const payload = { title: quiz.title, description: quiz.description, durationMinutes: quiz.durationMinutes,
      passPercentage: quiz.passPercentage, isPublished: quiz.isPublished };
    if (!quiz.locked) payload.questions = quiz.questions.map((q) => ({ text: q.text, marks: +q.marks || 1, options: q.options.map((o) => ({ text: o.text, isCorrect: !!o.isCorrect })) }));
    try {
      await api(id ? `/admin/quizzes/${id}` : '/admin/quizzes', { method: id ? 'PUT' : 'POST', body: payload });
      toast('Quiz saved', 'success');
      location.hash = '#/admin';
    } catch (e) {
      topError = e.message;
      fieldErrors = e instanceof ApiError ? e.fields : {};
      draw(root);
    }
  }

  function draw(prev) {
    if (prev) read(prev);
    const locked = quiz.locked;
    const root = el('section', {},
      el('a', { href: '#/admin' }, '← Back'),
      el('h2', {}, id ? 'Edit quiz' : 'New quiz'),
      topError ? el('div', { class: 'alert' }, topError, Object.values(fieldErrors).length ? el('ul', {}, Object.entries(fieldErrors).map(([k, v]) => el('li', {}, `${k}: ${v}`))) : null) : null,
      locked ? el('div', { class: 'alert alert-info' }, `Students have already attempted this quiz (${quiz.attemptCount}). Settings can be changed, but questions are locked to protect stored results.`) : null,
      el('div', { class: 'card' },
        field('Title', el('input', { name: 'title', value: quiz.title, maxlength: 150 })),
        field('Description', el('textarea', { name: 'description', rows: 2, value: quiz.description })),
        el('div', { class: 'row3' },
          field('Duration (minutes)', el('input', { name: 'duration', type: 'number', min: 1, max: 300, value: quiz.durationMinutes })),
          field('Pass percentage', el('input', { name: 'pass', type: 'number', min: 0, max: 100, value: quiz.passPercentage })),
          el('label', { class: 'field check' }, el('input', { name: 'published', type: 'checkbox', checked: quiz.isPublished }), el('span', {}, 'Published'))),
      ),
      el('h3', {}, `Questions (${quiz.questions.length})`),
      quiz.questions.map((q, qi) => el('div', { class: 'card q-edit' },
        el('div', { class: 'row-between' }, el('strong', {}, `Question ${qi + 1}`),
          !locked && quiz.questions.length > 1 ? el('button', { class: 'btn btn-sm btn-danger', onclick: () => { quiz.questions.splice(qi, 1); draw(root); } }, 'Remove') : null),
        el('div', { class: 'row2' },
          el('textarea', { rows: 2, placeholder: 'Question text', value: q.text, disabled: locked, oninput: (e) => (q.text = e.target.value) }),
          el('input', { type: 'number', min: 1, title: 'Marks', value: q.marks, disabled: locked, oninput: (e) => (q.marks = e.target.value) })),
        q.options.map((o, oi) => el('div', { class: 'opt-row' },
          el('input', { type: 'radio', name: `correct-${qi}`, checked: !!o.isCorrect, disabled: locked, title: 'Correct answer', onchange: () => q.options.forEach((x, k) => (x.isCorrect = k === oi)) }),
          el('input', { type: 'text', placeholder: `Option ${oi + 1}`, value: o.text, disabled: locked, oninput: (e) => (o.text = e.target.value) }),
          !locked && q.options.length > 2 ? el('button', { class: 'btn btn-sm btn-ghost', onclick: () => { const was = o.isCorrect; q.options.splice(oi, 1); if (was) q.options[0].isCorrect = true; draw(root); } }, '✕') : null)),
        !locked && q.options.length < 6 ? el('button', { class: 'btn btn-sm btn-ghost', onclick: () => { q.options.push({ text: '', isCorrect: false }); draw(root); } }, '+ Add option') : null)),
      el('div', { class: 'actions' },
        !locked ? el('button', { class: 'btn btn-ghost', onclick: () => { quiz.questions.push(blankQuestion()); draw(root); } }, '+ Add question') : null,
        el('button', { class: 'btn', onclick: () => save(root) }, 'Save quiz')));
    mount(root);
    window.scrollTo({ top: 0 });
  }
  draw();
}
