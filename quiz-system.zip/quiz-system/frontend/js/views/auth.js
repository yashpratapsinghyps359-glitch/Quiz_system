import { el, mount, field } from '../ui.js';
import { api, session } from '../api.js';

function authForm({ title, fields, submitLabel, path, footer }) {
  const inputs = {};
  const alertBox = el('div');
  const errs = {};
  const btn = el('button', { class: 'btn', type: 'submit' }, submitLabel);
  const form = el('form', { class: 'card auth', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    btn.disabled = true; alertBox.replaceChildren();
    Object.values(errs).forEach((n) => (n.textContent = ''));
    const body = Object.fromEntries(Object.entries(inputs).map(([k, i]) => [k, i.value]));
    try {
      const d = await api(path, { method: 'POST', body });
      session.save(d.token, d.user);
      location.hash = d.user.role === 'admin' ? '#/admin' : '#/';
    } catch (err) {
      alertBox.replaceChildren(el('div', { class: 'alert' }, err.message));
      Object.entries(err.fields).forEach(([k, v]) => { if (errs[k]) errs[k].textContent = v; });
    } finally { btn.disabled = false; }
  } }, el('h2', {}, title), alertBox);
  fields.forEach(([key, label, type]) => {
    inputs[key] = el('input', { type, name: key, autocomplete: type === 'password' ? 'current-password' : key });
    errs[key] = el('small', { class: 'err' });
    form.append(el('label', { class: 'field' }, el('span', {}, label), inputs[key], errs[key]));
  });
  form.append(btn, footer);
  mount(form);
}

export function loginView() {
  authForm({
    title: 'Sign in', path: '/auth/login', submitLabel: 'Sign in',
    fields: [['email', 'Email', 'email'], ['password', 'Password', 'password']],
    footer: el('p', { class: 'muted' }, 'New here? ', el('a', { href: '#/register' }, 'Create an account')),
  });
}

export function registerView() {
  authForm({
    title: 'Create account', path: '/auth/register', submitLabel: 'Register',
    fields: [['name', 'Name', 'text'], ['email', 'Email', 'email'], ['password', 'Password (min 6)', 'password']],
    footer: el('p', { class: 'muted' }, 'Already registered? ', el('a', { href: '#/login' }, 'Sign in')),
  });
}
