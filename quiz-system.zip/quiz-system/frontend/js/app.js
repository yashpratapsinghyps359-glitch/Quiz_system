import { el, mount, toast } from './ui.js';
import { session } from './api.js';
import { loginView, registerView } from './views/auth.js';
import { dashboardView, resultView } from './views/student.js';
import { takeView } from './views/take.js';
import { adminDashboardView, quizEditorView, quizResultsView } from './views/admin.js';

let cleanup = null;

function renderNav() {
  const user = session.user();
  const nav = document.getElementById('nav');
  nav.replaceChildren(
    el('div', { class: 'nav-inner' },
      el('a', { href: user?.role === 'admin' ? '#/admin' : '#/', class: 'brand' }, 'QuizHub'),
      el('nav', {},
        user
          ? [
              user.role === 'admin' ? el('a', { href: '#/admin' }, 'Admin') : el('a', { href: '#/' }, 'Quizzes'),
              el('span', { class: 'muted' }, `${user.name} (${user.role})`),
              el('button', { class: 'btn btn-ghost btn-sm', onclick: () => { session.clear(); location.hash = '#/login'; } }, 'Logout'),
            ]
          : [el('a', { href: '#/login' }, 'Login'), el('a', { href: '#/register' }, 'Register')]
      )
    )
  );
}

// route table: [regex, handler, role]  (role: null = public, 'any' = logged in, 'admin')
const routes = [
  [/^#\/login$/, loginView, null],
  [/^#\/register$/, registerView, null],
  [/^#\/?$/, dashboardView, 'any'],
  [/^#\/quiz\/(\d+)$/, takeView, 'any'],
  [/^#\/result\/(\d+)$/, resultView, 'any'],
  [/^#\/admin$/, adminDashboardView, 'admin'],
  [/^#\/admin\/new$/, quizEditorView, 'admin'],
  [/^#\/admin\/edit\/(\d+)$/, quizEditorView, 'admin'],
  [/^#\/admin\/results\/(\d+)$/, quizResultsView, 'admin'],
];

async function router() {
  if (cleanup) { cleanup(); cleanup = null; }
  const hash = location.hash || '#/';
  const user = session.user();
  renderNav();

  for (const [re, handler, role] of routes) {
    const m = hash.match(re);
    if (!m) continue;
    if (role && !user) { location.hash = '#/login'; return; }
    if (role === 'admin' && user.role !== 'admin') { toast('Admins only', 'error'); location.hash = '#/'; return; }
    if (!role && user) { location.hash = user.role === 'admin' ? '#/admin' : '#/'; return; }
    mount(el('p', { class: 'center muted' }, 'Loading...'));
    try {
      cleanup = (await handler(...m.slice(1))) || null;
    } catch (e) {
      mount(el('div', { class: 'card center' }, el('p', { class: 'err' }, e.message), el('a', { href: '#/' }, 'Go back')));
    }
    return;
  }
  location.hash = '#/';
}

window.addEventListener('hashchange', router);
router();
