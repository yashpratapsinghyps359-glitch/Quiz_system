const AppError = require('../utils/AppError');

const GRACE = parseInt(process.env.SUBMIT_GRACE_SECONDS || '5', 10);

// Locks the attempt row. `remaining` is computed by the DB clock (server-controlled timer).
async function lockAttempt(conn, id) {
  const [rows] = await conn.query(
    'SELECT a.*, TIMESTAMPDIFF(SECOND, NOW(), a.expires_at) AS remaining FROM attempts a WHERE a.id = ? FOR UPDATE', [id]);
  return rows[0] || null;
}

async function loadOwn(conn, id, user) {
  const a = await lockAttempt(conn, id);
  if (!a || (a.user_id !== user.id && user.role !== 'admin')) throw new AppError('Attempt not found', 404);
  return a;
}

// Score = SUM(marks) of questions whose chosen option is the correct one (join across 3 tables).
async function finalize(conn, attempt, status) {
  const [[t]] = await conn.query('SELECT COALESCE(SUM(marks),0) AS total FROM questions WHERE quiz_id = ?', [attempt.quiz_id]);
  const [[s]] = await conn.query(
    `SELECT COALESCE(SUM(q.marks),0) AS score
       FROM attempt_answers aa
       JOIN options   o ON o.id = aa.option_id AND o.is_correct = 1
       JOIN questions q ON q.id = aa.question_id
      WHERE aa.attempt_id = ?`, [attempt.id]);
  const [[z]] = await conn.query('SELECT pass_percentage FROM quizzes WHERE id = ?', [attempt.quiz_id]);
  const total = Number(t.total);
  const score = Number(s.score);
  const pct = total ? Math.round((score * 10000) / total) / 100 : 0;
  const passed = pct >= z.pass_percentage ? 1 : 0;
  await conn.query(
    `UPDATE attempts SET status = ?, score = ?, total_marks = ?, percentage = ?, passed = ?,
            submitted_at = IF(? = 'expired', expires_at, NOW())
      WHERE id = ? AND status = 'in_progress'`,
    [status, score, total, pct, passed, status, attempt.id]);
}

// An answer must belong to a question of THIS attempt's quiz.
async function upsertAnswer(conn, attempt, questionId, optionId) {
  const [ok] = await conn.query(
    `SELECT o.id FROM options o JOIN questions q ON q.id = o.question_id
      WHERE o.id = ? AND q.id = ? AND q.quiz_id = ?`, [optionId, questionId, attempt.quiz_id]);
  if (!ok.length) throw new AppError('Invalid question/option for this quiz', 400);
  await conn.query(
    `INSERT INTO attempt_answers (attempt_id, question_id, option_id) VALUES (?,?,?)
     ON DUPLICATE KEY UPDATE option_id = VALUES(option_id), answered_at = NOW()`,
    [attempt.id, questionId, optionId]);
}

// Questions WITHOUT the is_correct column - never leaks answers to students.
async function getQuestions(db, quizId, includeCorrect = false) {
  const [rows] = await db.query(
    `SELECT q.id AS qid, q.text AS qtext, q.marks, q.position, o.id AS oid, o.text AS otext, o.is_correct
       FROM questions q JOIN options o ON o.question_id = q.id
      WHERE q.quiz_id = ? ORDER BY q.position, o.id`, [quizId]);
  const map = new Map();
  rows.forEach((r) => {
    if (!map.has(r.qid)) map.set(r.qid, { id: r.qid, text: r.qtext, marks: r.marks, position: r.position, options: [] });
    const opt = { id: r.oid, text: r.otext };
    if (includeCorrect) opt.isCorrect = !!r.is_correct;
    map.get(r.qid).options.push(opt);
  });
  return [...map.values()];
}

async function buildPayload(db, attemptId) {
  const [[a]] = await db.query(
    `SELECT a.id, a.quiz_id, a.status, a.expires_at, z.title, z.duration_minutes,
            GREATEST(TIMESTAMPDIFF(SECOND, NOW(), a.expires_at), 0) AS remaining
       FROM attempts a JOIN quizzes z ON z.id = a.quiz_id WHERE a.id = ?`, [attemptId]);
  const questions = await getQuestions(db, a.quiz_id, false);
  const [ans] = await db.query('SELECT question_id, option_id FROM attempt_answers WHERE attempt_id = ?', [attemptId]);
  const answers = {};
  ans.forEach((r) => { answers[r.question_id] = r.option_id; });
  return {
    attempt: { id: a.id, quizId: a.quiz_id, title: a.title, status: a.status,
      durationMinutes: a.duration_minutes, remainingSeconds: Number(a.remaining), expiresAt: a.expires_at },
    questions, answers,
  };
}

// Background job: auto-submit attempts whose time ran out (and student never came back).
async function sweepExpired(withTransaction, pool) {
  const [rows] = await pool.query(
    "SELECT id FROM attempts WHERE status='in_progress' AND expires_at < DATE_SUB(NOW(), INTERVAL ? SECOND)", [GRACE]);
  for (const { id } of rows) {
    await withTransaction(async (conn) => {
      const a = await lockAttempt(conn, id);
      if (a && a.status === 'in_progress') await finalize(conn, a, 'expired');
    });
  }
  return rows.length;
}

module.exports = { GRACE, lockAttempt, loadOwn, finalize, upsertAnswer, getQuestions, buildPayload, sweepExpired };
