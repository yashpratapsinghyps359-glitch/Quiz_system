const { pool, withTransaction } = require('../config/db');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/attemptService');

// Published quizzes + this student's attempt state (LEFT JOIN).
exports.list = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT z.id, z.title, z.description, z.duration_minutes, z.pass_percentage,
            (SELECT COUNT(*)            FROM questions q WHERE q.quiz_id = z.id) AS question_count,
            (SELECT COALESCE(SUM(marks),0) FROM questions q WHERE q.quiz_id = z.id) AS total_marks,
            a.id AS attempt_id, a.status AS attempt_status, a.score, a.percentage, a.passed
       FROM quizzes z
       LEFT JOIN attempts a ON a.quiz_id = z.id AND a.user_id = ?
      WHERE z.is_published = 1 AND EXISTS (SELECT 1 FROM questions q WHERE q.quiz_id = z.id)
      ORDER BY z.created_at DESC`, [req.user.id]);
  res.json({ success: true, data: rows.map((r) => ({ ...r, passed: r.passed === null ? null : !!r.passed })) });
});

// Starts (or resumes) an attempt. The deadline is calculated by the DB clock.
exports.start = asyncHandler(async (req, res) => {
  const quizId = +req.params.id;
  const attemptId = await withTransaction(async (conn) => {
    const [[quiz]] = await conn.query('SELECT id, duration_minutes, is_published FROM quizzes WHERE id = ?', [quizId]);
    if (!quiz || !quiz.is_published) throw new AppError('Quiz not found', 404);
    const [[cnt]] = await conn.query('SELECT COUNT(*) AS n FROM questions WHERE quiz_id = ?', [quizId]);
    if (!cnt.n) throw new AppError('This quiz has no questions yet', 400);

    const [ex] = await conn.query('SELECT id FROM attempts WHERE user_id = ? AND quiz_id = ? FOR UPDATE', [req.user.id, quizId]);
    if (ex.length) return ex[0].id; // resume (or view finished result)

    const [r] = await conn.query(
      "INSERT INTO attempts (user_id, quiz_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE))",
      [req.user.id, quizId, quiz.duration_minutes]);
    return r.insertId;
  });
  res.status(201).json({ success: true, attemptId });
});
