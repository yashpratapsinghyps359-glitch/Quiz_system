const { pool, withTransaction } = require('../config/db');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const { getQuestions } = require('../services/attemptService');

async function insertQuestions(conn, quizId, questions) {
  for (let i = 0; i < questions.length; i++) {
    const q = questions[i];
    const [r] = await conn.query('INSERT INTO questions (quiz_id,text,marks,position) VALUES (?,?,?,?)',
      [quizId, q.text, q.marks || 1, i + 1]);
    for (const o of q.options) {
      await conn.query('INSERT INTO options (question_id,text,is_correct) VALUES (?,?,?)', [r.insertId, o.text, o.isCorrect ? 1 : 0]);
    }
  }
}

exports.stats = asyncHandler(async (req, res) => {
  const [[s]] = await pool.query(
    `SELECT (SELECT COUNT(*) FROM users WHERE role='student') AS students,
            (SELECT COUNT(*) FROM quizzes) AS quizzes,
            (SELECT COUNT(*) FROM attempts WHERE status <> 'in_progress') AS attempts,
            (SELECT ROUND(AVG(percentage),1) FROM attempts WHERE status <> 'in_progress') AS avg_score,
            (SELECT ROUND(100*AVG(passed),1) FROM attempts WHERE status <> 'in_progress') AS pass_rate`);
  res.json({ success: true, data: s });
});

exports.list = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT z.id, z.title, z.duration_minutes, z.pass_percentage, z.is_published, z.created_at, u.name AS author,
            (SELECT COUNT(*) FROM questions q WHERE q.quiz_id = z.id) AS question_count,
            COUNT(a.id) AS attempts, ROUND(AVG(a.percentage),1) AS avg_score
       FROM quizzes z
       JOIN users u ON u.id = z.created_by
       LEFT JOIN attempts a ON a.quiz_id = z.id AND a.status <> 'in_progress'
      GROUP BY z.id, u.name ORDER BY z.created_at DESC`);
  res.json({ success: true, data: rows.map((r) => ({ ...r, is_published: !!r.is_published })) });
});

exports.get = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const [[z]] = await pool.query(
    `SELECT z.*, (SELECT COUNT(*) FROM attempts a WHERE a.quiz_id = z.id) AS attempt_count FROM quizzes z WHERE z.id = ?`, [id]);
  if (!z) throw new AppError('Quiz not found', 404);
  res.json({
    success: true,
    data: {
      id: z.id, title: z.title, description: z.description, durationMinutes: z.duration_minutes,
      passPercentage: z.pass_percentage, isPublished: !!z.is_published,
      attemptCount: z.attempt_count, locked: z.attempt_count > 0,
      questions: await getQuestions(pool, id, true),
    },
  });
});

exports.create = asyncHandler(async (req, res) => {
  const { title, description = '', durationMinutes, passPercentage = 40, isPublished = false, questions } = req.body;
  const id = await withTransaction(async (conn) => {
    const [r] = await conn.query(
      'INSERT INTO quizzes (title,description,duration_minutes,pass_percentage,is_published,created_by) VALUES (?,?,?,?,?,?)',
      [title, description, durationMinutes, passPercentage, isPublished ? 1 : 0, req.user.id]);
    await insertQuestions(conn, r.insertId, questions);
    return r.insertId;
  });
  res.status(201).json({ success: true, data: { id } });
});

// Metadata can always change. Questions can only be replaced while NO attempt exists
// (protects the integrity of stored results).
exports.update = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const { title, description = '', durationMinutes, passPercentage = 40, isPublished = false, questions } = req.body;
  await withTransaction(async (conn) => {
    const [[z]] = await conn.query('SELECT id FROM quizzes WHERE id = ? FOR UPDATE', [id]);
    if (!z) throw new AppError('Quiz not found', 404);
    await conn.query(
      'UPDATE quizzes SET title=?, description=?, duration_minutes=?, pass_percentage=?, is_published=? WHERE id=?',
      [title, description, durationMinutes, passPercentage, isPublished ? 1 : 0, id]);
    if (questions) {
      const [[c]] = await conn.query('SELECT COUNT(*) AS n FROM attempts WHERE quiz_id = ?', [id]);
      if (c.n) throw new AppError('Questions can no longer be changed because students have already attempted this quiz.', 409);
      await conn.query('DELETE FROM questions WHERE quiz_id = ?', [id]);
      await insertQuestions(conn, id, questions);
    }
  });
  res.json({ success: true, message: 'Quiz updated' });
});

exports.setPublished = asyncHandler(async (req, res) => {
  const [r] = await pool.query('UPDATE quizzes SET is_published = ? WHERE id = ?', [req.body.isPublished ? 1 : 0, +req.params.id]);
  if (!r.affectedRows) throw new AppError('Quiz not found', 404);
  res.json({ success: true });
});

exports.remove = asyncHandler(async (req, res) => {
  try {
    const [r] = await pool.query('DELETE FROM quizzes WHERE id = ?', [+req.params.id]);
    if (!r.affectedRows) throw new AppError('Quiz not found', 404);
  } catch (e) {
    if (e.code === 'ER_ROW_IS_REFERENCED_2') throw new AppError('This quiz has stored results and cannot be deleted. Unpublish it instead.', 409);
    throw e;
  }
  res.json({ success: true, message: 'Quiz deleted' });
});

// Leaderboard: attempts JOIN users, ranked by score then speed.
exports.results = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const [[z]] = await pool.query('SELECT id, title, pass_percentage FROM quizzes WHERE id = ?', [id]);
  if (!z) throw new AppError('Quiz not found', 404);
  const [rows] = await pool.query(
    `SELECT a.id, u.name, u.email, a.score, a.total_marks, a.percentage, a.passed, a.status,
            a.submitted_at, TIMESTAMPDIFF(SECOND, a.started_at, a.submitted_at) AS seconds_taken
       FROM attempts a JOIN users u ON u.id = a.user_id
      WHERE a.quiz_id = ? AND a.status <> 'in_progress'
      ORDER BY a.percentage DESC, seconds_taken ASC`, [id]);
  res.json({ success: true, quiz: z, data: rows.map((r) => ({ ...r, passed: !!r.passed, percentage: Number(r.percentage) })) });
});

// Let a student retake: removes their attempt (answers cascade).
exports.deleteAttempt = asyncHandler(async (req, res) => {
  const [r] = await pool.query('DELETE FROM attempts WHERE id = ?', [+req.params.id]);
  if (!r.affectedRows) throw new AppError('Attempt not found', 404);
  res.json({ success: true, message: 'Attempt reset' });
});
