const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const sign = (u) => jwt.sign({ id: u.id, role: u.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });
const pub = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const hash = await bcrypt.hash(password, 12);
  try {
    const [r] = await pool.query('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)', [name, email, hash, 'student']);
    const user = { id: r.insertId, name, email, role: 'student' };
    res.status(201).json({ success: true, token: sign(user), user: pub(user) });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new AppError('Email already registered', 409, [{ field: 'email', message: 'Email already registered' }]);
    throw e;
  }
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) throw new AppError('Invalid email or password', 401);
  res.json({ success: true, token: sign(user), user: pub(user) });
});

exports.me = asyncHandler(async (req, res) => res.json({ success: true, user: req.user }));
