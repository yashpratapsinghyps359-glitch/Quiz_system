const { pool, withTransaction } = require('../config/db');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');
const svc = require('../services/attemptService');

// Current state of an attempt (used to start/resume). Lazily closes it if time is over.
exports.get = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const status = await withTransaction(async (conn) => {
    let a = await svc.loadOwn(conn, id, req.user);
    if (a.status === 'in_progress' && a.remaining < -svc.GRACE) {
      await svc.finalize(conn, a, 'expired');
      return 'expired';
    }
    return a.status;
  });
  if (status !== 'in_progress') return res.json({ success: true, finished: true, attemptId: id });
  res.json({ success: true, finished: false, ...(await svc.buildPayload(pool, id)) });
});

// Autosave one answer. Rejected once the server clock says time is up.
exports.saveAnswer = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const { questionId, optionId } = req.body;
  const out = await withTransaction(async (conn) => {
    const a = await svc.loadOwn(conn, id, req.user);
    if (a.status !== 'in_progress') return { closed: true };
    if (a.remaining < -svc.GRACE) { await svc.finalize(conn, a, 'expired'); return { closed: true }; }
    if (a.remaining <= 0) return { closed: true, soft: true };
    await svc.upsertAnswer(conn, a, questionId, optionId);
    return { remaining: a.remaining };
  });
  if (out.closed) throw new AppError('Time is up. This attempt is closed.', 409);
  res.json({ success: true, remainingSeconds: Number(out.remaining) });
});

// Submit. Answers in the payload are accepted only inside (deadline + grace).
exports.submit = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const answers = req.body.answers || [];
  await withTransaction(async (conn) => {
    const a = await svc.loadOwn(conn, id, req.user);
    if (a.status !== 'in_progress') return; // idempotent
    const late = a.remaining < -svc.GRACE;
    if (!late) for (const ans of answers) await svc.upsertAnswer(conn, a, ans.questionId, ans.optionId);
    await svc.finalize(conn, a, late ? 'expired' : 'submitted');
  });
  res.json({ success: true, attemptId: id });
});

// Result + per-question review (only after the attempt is closed).
exports.result = asyncHandler(async (req, res) => {
  const id = +req.params.id;
  const [[a]] = await pool.query(
    `SELECT a.*, z.title, z.pass_percentage, z.duration_minutes, u.name AS student
       FROM attempts a JOIN quizzes z ON z.id = a.quiz_id JOIN users u ON u.id = a.user_id WHERE a.id = ?`, [id]);
  if (!a || (a.user_id !== req.user.id && req.user.role !== 'admin')) throw new AppError('Attempt not found', 404);
  if (a.status === 'in_progress') throw new AppError('Result is available after the quiz is submitted', 409);

  const [rows] = await pool.query(
    `SELECT q.id AS qid, q.text AS qtext, q.marks, o.id AS oid, o.text AS otext, o.is_correct,
            (aa.option_id = o.id) AS selected
       FROM questions q
       JOIN options o ON o.question_id = q.id
       LEFT JOIN attempt_answers aa ON aa.question_id = q.id AND aa.attempt_id = ?
      WHERE q.quiz_id = ? ORDER BY q.position, o.id`, [id, a.quiz_id]);
  const map = new Map();
  rows.forEach((r) => {
    if (!map.has(r.qid)) map.set(r.qid, { id: r.qid, text: r.qtext, marks: r.marks, answered: false, correct: false, options: [] });
    const q = map.get(r.qid);
    const sel = !!r.selected, cor = !!r.is_correct;
    if (sel) { q.answered = true; q.correct = cor; }
    q.options.push({ id: r.oid, text: r.otext, selected: sel, isCorrect: cor });
  });
  res.json({
    success: true,
    data: {
      id: a.id, quiz: a.title, student: a.student, status: a.status, score: a.score, totalMarks: a.total_marks,
      percentage: Number(a.percentage), passed: !!a.passed, passPercentage: a.pass_percentage,
      startedAt: a.started_at, submittedAt: a.submitted_at, questions: [...map.values()],
    },
  });
});

exports.mine = asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, z.title, a.status, a.score, a.total_marks, a.percentage, a.passed, a.submitted_at
       FROM attempts a JOIN quizzes z ON z.id = a.quiz_id
      WHERE a.user_id = ? AND a.status <> 'in_progress' ORDER BY a.submitted_at DESC`, [req.user.id]);
  res.json({ success: true, data: rows.map((r) => ({ ...r, passed: !!r.passed })) });
});
