const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const routes = require('./routes');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const app = express();
app.use(helmet({ contentSecurityPolicy: { useDefaults: true, directives: { 'upgrade-insecure-requests': null } } }));
app.use(cors());
app.use(express.json({ limit: '200kb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));

app.get('/api/health', (req, res) => res.json({ success: true, status: 'ok' }));
app.use('/api', routes);
app.use('/api', notFound);

// Frontend (plain HTML/CSS/JS) is served by the same server.
app.use(express.static(path.join(__dirname, '..', '..', 'frontend')));
app.use(notFound);
app.use(errorHandler);

module.exports = app;
