const router = require('express').Router();
const { body, param } = require('express-validator');
const rateLimit = require('express-rate-limit');
const validate = require('../middleware/validate');
const { protect, restrictTo } = require('../middleware/auth');
const auth = require('../controllers/authController');
const quiz = require('../controllers/quizController');
const attempt = require('../controllers/attemptController');
const admin = require('../controllers/adminController');

const idParam = param('id').isInt({ min: 1 }).withMessage('Invalid id');
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 50, standardHeaders: true, legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Try again later.' } });

// ---------- Auth ----------
router.post('/auth/register', authLimiter, [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 60 }).withMessage('Name too long'),
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('password').isLength({ min: 6, max: 72 }).withMessage('Password must be 6-72 characters'),
], validate, auth.register);
router.post('/auth/login', authLimiter, [
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('password').notEmpty().withMessage('Password is required'),
], validate, auth.login);
router.get('/auth/me', protect, auth.me);

// ---------- Student ----------
router.get('/quizzes', protect, quiz.list);
router.post('/quizzes/:id/start', protect, [idParam], validate, quiz.start);
router.get('/attempts/mine', protect, attempt.mine);
router.get('/attempts/:id', protect, [idParam], validate, attempt.get);
router.put('/attempts/:id/answers', protect, [
  idParam,
  body('questionId').isInt({ min: 1 }).withMessage('questionId is required'),
  body('optionId').isInt({ min: 1 }).withMessage('optionId is required'),
], validate, attempt.saveAnswer);
router.post('/attempts/:id/submit', protect, [
  idParam,
  body('answers').optional().isArray({ max: 200 }).withMessage('answers must be an array'),
  body('answers.*.questionId').isInt({ min: 1 }),
  body('answers.*.optionId').isInt({ min: 1 }),
], validate, attempt.submit);
router.get('/attempts/:id/result', protect, [idParam], validate, attempt.result);

// ---------- Admin ----------
const quizRules = [
  body('title').trim().notEmpty().withMessage('Title is required').isLength({ max: 150 }).withMessage('Title max 150 chars'),
  body('description').optional().isString().isLength({ max: 500 }).withMessage('Description max 500 chars'),
  body('durationMinutes').isInt({ min: 1, max: 300 }).withMessage('Duration must be 1-300 minutes'),
  body('passPercentage').optional().isInt({ min: 0, max: 100 }).withMessage('Pass percentage must be 0-100'),
  body('isPublished').optional().isBoolean().withMessage('isPublished must be boolean'),
];
const questionRules = (required) => [
  required
    ? body('questions').isArray({ min: 1, max: 100 }).withMessage('Add 1-100 questions')
    : body('questions').optional().isArray({ min: 1, max: 100 }).withMessage('Add 1-100 questions'),
  body('questions.*.text').trim().notEmpty().withMessage('Question text is required').isLength({ max: 1000 }),
  body('questions.*.marks').optional().isInt({ min: 1, max: 100 }).withMessage('Marks must be 1-100'),
  body('questions.*.options').isArray({ min: 2, max: 6 }).withMessage('Each question needs 2-6 options'),
  body('questions.*.options.*.text').trim().notEmpty().withMessage('Option text is required').isLength({ max: 500 }),
  body('questions').if(body('questions').exists()).custom((qs) => {
    qs.forEach((q, i) => {
      const n = (q.options || []).filter((o) => o && o.isCorrect === true).length;
      if (n !== 1) throw new Error(`Question ${i + 1} must have exactly one correct option`);
    });
    return true;
  }),
];

router.use('/admin', protect, restrictTo('admin'));
router.get('/admin/stats', admin.stats);
router.get('/admin/quizzes', admin.list);
router.post('/admin/quizzes', quizRules, questionRules(true), validate, admin.create);
router.get('/admin/quizzes/:id', [idParam], validate, admin.get);
router.put('/admin/quizzes/:id', [idParam], quizRules, questionRules(false), validate, admin.update);
router.patch('/admin/quizzes/:id/publish', [idParam, body('isPublished').isBoolean()], validate, admin.setPublished);
router.delete('/admin/quizzes/:id', [idParam], validate, admin.remove);
router.get('/admin/quizzes/:id/results', [idParam], validate, admin.results);
router.delete('/admin/attempts/:id', [idParam], validate, admin.deleteAttempt);

module.exports = router;
