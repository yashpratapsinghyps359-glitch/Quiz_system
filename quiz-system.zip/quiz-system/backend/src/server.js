require('dotenv').config();
const app = require('./app');
const { pool, withTransaction } = require('./config/db');
const { sweepExpired } = require('./services/attemptService');

const PORT = process.env.PORT || 3000;

(async () => {
  try {
    await pool.query('SELECT 1');
    console.log('MySQL connected');
  } catch (e) {
    console.error('Cannot connect to MySQL:', e.message);
    process.exit(1);
  }
  app.listen(PORT, () => console.log(`Quiz system running on http://localhost:${PORT}`));

  // Auto-submit attempts whose timer expired (server-side enforcement)
  setInterval(() => sweepExpired(withTransaction, pool).catch((e) => console.error('sweep failed:', e.message)), 30000);
})();
