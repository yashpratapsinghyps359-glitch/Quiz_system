const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

exports.protect = asyncHandler(async (req, res, next) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) throw new AppError('Not authenticated. Please log in.', 401);
  const { id } = jwt.verify(token, process.env.JWT_SECRET);
  const [rows] = await pool.query('SELECT id,name,email,role FROM users WHERE id=?', [id]);
  if (!rows.length) throw new AppError('User no longer exists.', 401);
  req.user = rows[0];
  next();
});

exports.restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) return next(new AppError('You do not have permission to do this.', 403));
  next();
};
