const AppError = require('../utils/AppError');

exports.notFound = (req, res, next) => next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));

exports.errorHandler = (err, req, res, next) => { // eslint-disable-line no-unused-vars
  let e = err;
  switch (true) {
    case err.type === 'entity.parse.failed': e = new AppError('Malformed JSON body', 400); break;
    case err.name === 'JsonWebTokenError': e = new AppError('Invalid token. Please log in again.', 401); break;
    case err.name === 'TokenExpiredError': e = new AppError('Session expired. Please log in again.', 401); break;
    case err.code === 'ER_DUP_ENTRY': e = new AppError('A record with the same unique value already exists.', 409); break;
    case err.code === 'ER_NO_REFERENCED_ROW_2': e = new AppError('Referenced record does not exist.', 400); break;
    case err.code === 'ER_ROW_IS_REFERENCED_2': e = new AppError('Cannot delete: other records depend on this one.', 409); break;
    case err.code === 'ER_DATA_TOO_LONG' || err.code === 'ER_BAD_NULL_ERROR' || err.code === 'ER_CHECK_CONSTRAINT_VIOLATED':
      e = new AppError('Invalid data for one or more fields.', 400); break;
    default:
  }
  const status = e.statusCode || 500;
  if (status === 500) console.error(err);
  res.status(status).json({
    success: false,
    message: e.isOperational ? e.message : 'Internal server error',
    ...(e.errors && { errors: e.errors }),
  });
};
