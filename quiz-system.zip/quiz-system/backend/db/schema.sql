-- Online Quiz System - normalized schema (3NF)
-- users 1--* quizzes(created_by) ; quizzes 1--* questions ; questions 1--* options
-- users 1--* attempts *--1 quizzes ; attempts 1--* attempt_answers *--1 questions/options
CREATE DATABASE IF NOT EXISTS quiz_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE quiz_system;

CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name          VARCHAR(60)  NOT NULL,
  email         VARCHAR(120) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role          ENUM('admin','student') NOT NULL DEFAULT 'student',
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS quizzes (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title            VARCHAR(150) NOT NULL,
  description      VARCHAR(500) NOT NULL DEFAULT '',
  duration_minutes SMALLINT UNSIGNED NOT NULL,
  pass_percentage  TINYINT UNSIGNED NOT NULL DEFAULT 40,
  is_published     TINYINT(1) NOT NULL DEFAULT 0,
  created_by       INT UNSIGNED NOT NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_quiz_duration CHECK (duration_minutes BETWEEN 1 AND 300),
  CONSTRAINT chk_quiz_pass CHECK (pass_percentage BETWEEN 0 AND 100),
  CONSTRAINT fk_quizzes_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questions (
  id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  quiz_id  INT UNSIGNED NOT NULL,
  text     VARCHAR(1000) NOT NULL,
  marks    TINYINT UNSIGNED NOT NULL DEFAULT 1,
  position SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_question_position (quiz_id, position),
  CONSTRAINT chk_question_marks CHECK (marks > 0),
  CONSTRAINT fk_questions_quiz FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- correct_flag is 1 for the correct option and NULL otherwise. A UNIQUE index on
-- (question_id, correct_flag) lets MySQL itself guarantee at most ONE correct option per question.
CREATE TABLE IF NOT EXISTS options (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  question_id INT UNSIGNED NOT NULL,
  text        VARCHAR(500) NOT NULL,
  is_correct  TINYINT(1) NOT NULL DEFAULT 0,
  correct_flag TINYINT AS (IF(is_correct = 1, 1, NULL)) VIRTUAL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_one_correct_per_question (question_id, correct_flag),
  CONSTRAINT fk_options_question FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- One attempt per student per quiz. expires_at is set by the DATABASE clock when the quiz starts.
CREATE TABLE IF NOT EXISTS attempts (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED NOT NULL,
  quiz_id      INT UNSIGNED NOT NULL,
  status       ENUM('in_progress','submitted','expired') NOT NULL DEFAULT 'in_progress',
  started_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at   DATETIME NOT NULL,
  submitted_at DATETIME NULL,
  score        INT UNSIGNED NULL,
  total_marks  INT UNSIGNED NULL,
  percentage   DECIMAL(5,2) NULL,
  passed       TINYINT(1) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attempt_user_quiz (user_id, quiz_id),
  KEY idx_attempts_quiz_status (quiz_id, status),
  KEY idx_attempts_expiry (status, expires_at),
  CONSTRAINT fk_attempts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_attempts_quiz FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS attempt_answers (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  attempt_id  INT UNSIGNED NOT NULL,
  question_id INT UNSIGNED NOT NULL,
  option_id   INT UNSIGNED NOT NULL,
  answered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_answer_once (attempt_id, question_id),
  CONSTRAINT fk_ans_attempt  FOREIGN KEY (attempt_id)  REFERENCES attempts(id)  ON DELETE CASCADE,
  CONSTRAINT fk_ans_question FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
  CONSTRAINT fk_ans_option   FOREIGN KEY (option_id)   REFERENCES options(id)   ON DELETE CASCADE
) ENGINE=InnoDB;
