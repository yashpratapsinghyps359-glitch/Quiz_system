require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('../src/config/db');

const SAMPLE = {
  title: 'JavaScript Basics', description: 'Check your core JavaScript knowledge.',
  duration: 5, pass: 60,
  questions: [
    ['Which keyword declares a block-scoped variable?', ['var', 'let', 'function', 'define'], 1],
    ['What does typeof null return?', ['"null"', '"undefined"', '"object"', '"number"'], 2],
    ['Which method adds an element to the end of an array?', ['push()', 'pop()', 'shift()', 'unshift()'], 0],
    ['What is the result of 2 + "2" in JavaScript?', ['4', '"22"', 'NaN', 'Error'], 1],
    ['Which operator checks both value and type equality?', ['==', '=', '===', '!='], 2],
  ],
};

async function upsertUser(name, email, password, role) {
  const [rows] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
  if (rows.length) return rows[0].id;
  const [r] = await pool.query('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)',
    [name, email, await bcrypt.hash(password, 12), role]);
  return r.insertId;
}

(async () => {
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@quiz.com';
  const adminId = await upsertUser('Admin', adminEmail, process.env.ADMIN_PASSWORD || 'Admin@123', 'admin');
  await upsertUser('Demo Student', 'student@quiz.com', 'Student@123', 'student');

  const [ex] = await pool.query('SELECT id FROM quizzes WHERE title=?', [SAMPLE.title]);
  if (!ex.length) {
    const [q] = await pool.query(
      'INSERT INTO quizzes (title,description,duration_minutes,pass_percentage,is_published,created_by) VALUES (?,?,?,?,1,?)',
      [SAMPLE.title, SAMPLE.description, SAMPLE.duration, SAMPLE.pass, adminId]);
    let pos = 1;
    for (const [text, opts, correct] of SAMPLE.questions) {
      const [qr] = await pool.query('INSERT INTO questions (quiz_id,text,marks,position) VALUES (?,?,?,?)', [q.insertId, text, 1, pos++]);
      for (let i = 0; i < opts.length; i++) {
        await pool.query('INSERT INTO options (question_id,text,is_correct) VALUES (?,?,?)', [qr.insertId, opts[i], i === correct ? 1 : 0]);
      }
    }
  }
  console.log(`Seed complete.\n  Admin:   ${adminEmail} / ${process.env.ADMIN_PASSWORD || 'Admin@123'}\n  Student: student@quiz.com / Student@123`);
  await pool.end();
})().catch((e) => { console.error('db:seed failed ->', e.message); process.exit(1); });
