require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

(async () => {
  const dbName = process.env.DB_NAME || 'quiz_system';
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8').replace(/quiz_system/g, dbName);
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: +(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });
  await conn.query(sql);
  console.log(`Database "${dbName}" is ready (tables created).`);
  await conn.end();
})().catch((e) => { console.error('db:init failed ->', e.message); process.exit(1); });
